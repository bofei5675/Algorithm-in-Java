package RedBlackTree;

public enum NodeColor {
    BLACK, RED;

}
