package LRUCache;

public class DoublyLinkedList {
    private Node head;
    private Node tail;
    private int size;

    public Node getHead() {
        return this.head;
    }

    public void setHead(Node head) {
        this.head = head;
    }

    public Node getTail() {
        return this.tail;
    }

    public void setTail(Node tail) {
        this.tail = tail;
    }

}
