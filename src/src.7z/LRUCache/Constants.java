package LRUCache;

public class Constants {
    private Constants() {
        // disable constructor
    }

    public final static int CAPACITY = 4;

}
