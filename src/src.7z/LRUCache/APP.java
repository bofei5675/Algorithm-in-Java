package LRUCache;

public class APP {

}
