package Arrays;

/**
 * Simple HelloWorld program (clear of Checkstyle and FindBugs warnings).
 *
 * @author P. Bucci
 */
public class App {

    public static void main(String[] args) {

        System.out.println("Hello World!!!");
    }

}
