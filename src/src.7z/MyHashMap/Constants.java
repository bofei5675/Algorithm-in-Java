package MyHashMap;

public class Constants {
    // store max 10 items in the hash table
    public final static int TABLE_SIZE = 10;

}
