package GenericHashMap;

public class Constants {
    public static final int TABLE_SIZE = 10;

}
